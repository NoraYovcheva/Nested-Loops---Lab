﻿using System;

namespace _07.CinemaTickets
{
    class Program
    {
        static void Main(string[] args)
        {
            int studentTickets = 0;
            int standartTickets = 0;
            int kidTickets = 0;

            while (true)
            {
                string input = Console.ReadLine();

                if (input == "Finish")
                {
                    break;
                }

                int freeSpots = int.Parse(Console.ReadLine());
                int currentFreeSpots = freeSpots;

                while (currentFreeSpots > 0)
                {
                    string ticketsType = Console.ReadLine();
                    if (ticketsType == "End")
                    {
                        break;
                    }
                    currentFreeSpots--;
                    if (ticketsType == "standart")
                    {
                        standartTickets++;
                    }
                    else if (ticketsType == "student")
                    {
                        studentTickets++;
                    }
                    else if (ticketsType == "kid")
                    {
                        kidTickets++;
                    }

                }
                double freeSpotsInPercentage = 100 - (currentFreeSpots * 1.0 / freeSpots * 100);

                Console.WriteLine($"{input} - {freeSpotsInPercentage:f2}% full.");
            }

            int totalTickets = standartTickets + studentTickets + kidTickets;
            double studentsTicketsPercentAge = studentTickets * 1.0 / totalTickets * 100;
            double standartsTicketsPercentage = standartTickets * 1.0 / totalTickets * 100;
            double kidsTicketsPercentage = kidTickets * 1.0 / totalTickets * 100;

            Console.WriteLine($"Total tickets: {totalTickets}");
            Console.WriteLine($"{studentsTicketsPercentAge:f2} student tickets.");
            Console.WriteLine($"{standartsTicketsPercentage:f2} standard tickets.");
            Console.WriteLine($"{kidsTicketsPercentage:f2} kid tickets.");
        }
    }
}
