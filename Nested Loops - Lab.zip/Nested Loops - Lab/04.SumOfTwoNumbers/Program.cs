﻿using System;
using System.Globalization;

namespace _04.SumOfTwoNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            //int startNumber = int.Parse(Console.ReadLine());
            //int finalNumber = int.Parse(Console.ReadLine());
            //int magicNumber = int.Parse(Console.ReadLine());
            //int combinations = 0;

            //bool isFound = false;
            //for (int i = startNumber; i <= finalNumber; i++)
            //{
            //    for (int j = startNumber; j <= finalNumber; j++)
            //        combinations++;
            //    {
            //        if (i + j == magicNumber)
            //        {
            //            Console.WriteLine($"Combination N:{ combinations} ({i}+ {j} = { magicNumber})");
            //        }
            //        isFound = true;
            //        break;
            //    }

            //    if (isFound)
            //    {
            //        break;
            //    }
            //}
            
        }
    }
}
